<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-30 20:55:21 --> Could not find the language line "cannot_connect_database_server"
ERROR - 2017-12-30 20:55:21 --> Could not find the language line "cannot_connect_database_server"
DEBUG - 2017-12-30 21:02:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:08 --> No URI present. Default controller set.
DEBUG - 2017-12-30 21:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:08 --> Dashboard MX_Controller Initialized
DEBUG - 2017-12-30 21:02:08 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:08 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:08 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:08 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:08 --> Sessions MX_Controller Initialized
DEBUG - 2017-12-30 21:02:08 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:08 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:08 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:08 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:08 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:02:08 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/sessions/views/session_login.php
DEBUG - 2017-12-30 21:02:08 --> Total execution time: 0.0322
DEBUG - 2017-12-30 21:02:09 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:09 --> Sessions MX_Controller Initialized
DEBUG - 2017-12-30 21:02:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:09 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:09 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:02:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/sessions/views/session_login.php
DEBUG - 2017-12-30 21:02:09 --> Total execution time: 0.0443
DEBUG - 2017-12-30 21:02:19 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:19 --> Sessions MX_Controller Initialized
DEBUG - 2017-12-30 21:02:19 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:19 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:19 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:19 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:19 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/sessions/models/Mdl_sessions.php
DEBUG - 2017-12-30 21:02:20 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:20 --> Sessions MX_Controller Initialized
DEBUG - 2017-12-30 21:02:20 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:20 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:20 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:02:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/sessions/views/session_login.php
DEBUG - 2017-12-30 21:02:20 --> Total execution time: 0.0569
DEBUG - 2017-12-30 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:29 --> Sessions MX_Controller Initialized
DEBUG - 2017-12-30 21:02:29 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:29 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/sessions/models/Mdl_sessions.php
DEBUG - 2017-12-30 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:29 --> Dashboard MX_Controller Initialized
DEBUG - 2017-12-30 21:02:29 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:29 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_amounts.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quote_amounts.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quotes.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/projects/models/Mdl_projects.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tasks/models/Mdl_tasks.php
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
ERROR - 2017-12-30 21:02:29 --> Could not find the language line ""
ERROR - 2017-12-30 21:02:29 --> Could not find the language line ""
DEBUG - 2017-12-30 21:02:29 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/dashboard/views/index.php
DEBUG - 2017-12-30 21:02:30 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:02:30 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:02:30 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:02:30 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:02:30 --> Total execution time: 0.1581
DEBUG - 2017-12-30 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:02:43 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:02:43 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:02:43 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:02:43 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:02:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:02:43 --> Total execution time: 0.2538
DEBUG - 2017-12-30 21:04:32 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:32 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:04:32 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:32 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:32 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:32 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:04:33 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:33 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:04:33 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:33 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:33 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:04:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:04:33 --> Total execution time: 0.0578
DEBUG - 2017-12-30 21:04:37 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:37 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:04:37 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:37 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/script_select2_client_id.js
DEBUG - 2017-12-30 21:04:37 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/modal_create_invoice.php
DEBUG - 2017-12-30 21:04:37 --> Total execution time: 0.0748
DEBUG - 2017-12-30 21:04:42 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:42 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:04:42 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:42 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:42 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:42 --> Total execution time: 0.0535
DEBUG - 2017-12-30 21:04:43 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:43 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:04:43 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:43 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:43 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:43 --> Total execution time: 0.0391
DEBUG - 2017-12-30 21:04:43 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:43 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:04:43 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:43 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:43 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:43 --> Total execution time: 0.0381
DEBUG - 2017-12-30 21:04:47 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:47 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:04:47 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:47 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:47 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:47 --> Total execution time: 0.0620
DEBUG - 2017-12-30 21:04:50 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:50 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:04:50 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:50 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:50 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:50 --> Total execution time: 0.0492
DEBUG - 2017-12-30 21:04:54 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:04:54 --> Clients MX_Controller Initialized
DEBUG - 2017-12-30 21:04:54 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:04:54 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/form.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:04:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:04:54 --> Total execution time: 0.1029
DEBUG - 2017-12-30 21:05:54 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:05:54 --> Clients MX_Controller Initialized
DEBUG - 2017-12-30 21:05:54 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:05:54 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/user_clients/models/Mdl_user_clients.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/users/models/Mdl_users.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:05:54 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:05:54 --> Clients MX_Controller Initialized
DEBUG - 2017-12-30 21:05:54 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:05:54 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_client_notes.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quotes.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/custom_fields/controllers/Custom_fields.php
DEBUG - 2017-12-30 21:05:54 --> Custom_Fields MX_Controller Initialized
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/partial_invoice_table.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/views/partial_quote_table.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/views/partial_payment_table.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/partial_notes.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/partial_client_address.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/view.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:05:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:05:54 --> Total execution time: 0.1242
DEBUG - 2017-12-30 21:05:56 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:05:56 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:05:56 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:05:56 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/script_select2_client_id.js
DEBUG - 2017-12-30 21:05:56 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/modal_create_invoice.php
DEBUG - 2017-12-30 21:05:56 --> Total execution time: 0.0529
DEBUG - 2017-12-30 21:05:58 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:05:58 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:05:58 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:05:58 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:05:58 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:05:58 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:05:58 --> Total execution time: 0.0400
DEBUG - 2017-12-30 21:06:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:00 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:06:00 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:00 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:00 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:00 --> Total execution time: 0.0398
DEBUG - 2017-12-30 21:06:04 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:04 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:06:04 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:04 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:04 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:04 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:04 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:06:04 --> Total execution time: 0.0493
DEBUG - 2017-12-30 21:06:10 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:10 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:06:10 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:10 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/models/Mdl_clients.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:06:10 --> Total execution time: 0.0424
DEBUG - 2017-12-30 21:06:10 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:10 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:06:10 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:10 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/units/models/Mdl_units.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/payments/controllers/Payments.php
DEBUG - 2017-12-30 21:06:10 --> Payments MX_Controller Initialized
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/modal_delete_invoice.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/modal_add_invoice_tax.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/views/modal_add_payment.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/partial_client_address.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/partial_item_table.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-html.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-scripts.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/view.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:06:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:06:10 --> Total execution time: 0.1662
DEBUG - 2017-12-30 21:06:11 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:11 --> Upload MX_Controller Initialized
DEBUG - 2017-12-30 21:06:11 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:11 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:11 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:11 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:11 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:06:11 --> Total execution time: 0.0601
DEBUG - 2017-12-30 21:06:47 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:47 --> Ajax MX_Controller Initialized
DEBUG - 2017-12-30 21:06:47 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:47 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/units/models/Mdl_units.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_sumex.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_item_amounts.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_amounts.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:06:47 --> Total execution time: 0.0874
DEBUG - 2017-12-30 21:06:47 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:47 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:06:47 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:47 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/units/models/Mdl_units.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/payments/controllers/Payments.php
DEBUG - 2017-12-30 21:06:47 --> Payments MX_Controller Initialized
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/modal_delete_invoice.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/modal_add_invoice_tax.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/views/modal_add_payment.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/clients/views/partial_client_address.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/partial_item_table.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-html.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-scripts.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/view.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:06:47 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:06:47 --> Total execution time: 0.0555
DEBUG - 2017-12-30 21:06:48 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:48 --> Upload MX_Controller Initialized
DEBUG - 2017-12-30 21:06:48 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:48 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:48 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:48 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:48 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:06:48 --> Total execution time: 0.0379
DEBUG - 2017-12-30 21:06:50 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:06:50 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:06:50 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:06:50 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
DEBUG - 2017-12-30 21:06:50 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 21:06:52 --> Total execution time: 2.2300
DEBUG - 2017-12-30 21:09:20 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:09:20 --> Mailer MX_Controller Initialized
DEBUG - 2017-12-30 21:09:20 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:09:20 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/views/template-tags.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-html.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-scripts.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/mailer/views/invoice.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:09:20 --> Total execution time: 0.0830
DEBUG - 2017-12-30 21:09:20 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:09:20 --> Upload MX_Controller Initialized
DEBUG - 2017-12-30 21:09:20 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:09:20 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:09:20 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:09:20 --> Total execution time: 0.0339
DEBUG - 2017-12-30 21:09:59 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:09:59 --> Mailer MX_Controller Initialized
DEBUG - 2017-12-30 21:09:59 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:09:59 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/mailer/helpers/phpmailer_helper.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
DEBUG - 2017-12-30 21:09:59 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 21:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:10:02 --> Mailer MX_Controller Initialized
DEBUG - 2017-12-30 21:10:02 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:10:02 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/views/template-tags.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-html.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-scripts.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/mailer/views/invoice.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:10:02 --> Total execution time: 0.0930
DEBUG - 2017-12-30 21:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:10:02 --> Upload MX_Controller Initialized
DEBUG - 2017-12-30 21:10:02 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:10:02 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:10:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:10:02 --> Total execution time: 0.0553
DEBUG - 2017-12-30 21:10:55 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:10:55 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:10:55 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:10:55 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:10:55 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:10:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:10:55 --> Total execution time: 0.0828
DEBUG - 2017-12-30 21:11:01 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:01 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:11:01 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:01 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:01 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:11:01 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:11:01 --> Total execution time: 0.0635
DEBUG - 2017-12-30 21:11:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:08 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:11:08 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:08 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:08 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:08 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:08 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:09 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 21:11:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:09 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:11:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:11:09 --> Total execution time: 0.0684
DEBUG - 2017-12-30 21:11:13 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:13 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:11:13 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:13 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:11:13 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:13 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:11:13 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:13 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/partial_invoice_table.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/index.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/filter/views/jquery_filter.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:11:13 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:11:13 --> Total execution time: 0.0724
DEBUG - 2017-12-30 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:17 --> Mailer MX_Controller Initialized
DEBUG - 2017-12-30 21:11:17 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:17 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/views/template-tags.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-html.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-scripts.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/mailer/views/invoice.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:11:17 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:11:17 --> Total execution time: 0.0540
DEBUG - 2017-12-30 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:17 --> Upload MX_Controller Initialized
DEBUG - 2017-12-30 21:11:17 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:18 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:11:18 --> Total execution time: 0.0314
DEBUG - 2017-12-30 21:11:18 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:18 --> Mailer MX_Controller Initialized
DEBUG - 2017-12-30 21:11:18 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:18 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/mailer/helpers/phpmailer_helper.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
DEBUG - 2017-12-30 21:11:18 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 21:11:23 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:23 --> Mailer MX_Controller Initialized
DEBUG - 2017-12-30 21:11:23 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:23 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/views/template-tags.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-html.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/views/dropzone-invoice-scripts.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/mailer/views/invoice.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:11:23 --> Total execution time: 0.0655
DEBUG - 2017-12-30 21:11:23 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:11:23 --> Upload MX_Controller Initialized
DEBUG - 2017-12-30 21:11:23 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:11:23 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:11:23 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/upload/models/Mdl_uploads.php
DEBUG - 2017-12-30 21:11:23 --> Total execution time: 0.0534
DEBUG - 2017-12-30 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:40:32 --> No URI present. Default controller set.
DEBUG - 2017-12-30 21:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:40:32 --> Dashboard MX_Controller Initialized
DEBUG - 2017-12-30 21:40:32 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:40:32 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_amounts.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quote_amounts.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quotes.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/projects/models/Mdl_projects.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tasks/models/Mdl_tasks.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/dashboard/views/index.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:40:32 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:40:32 --> Total execution time: 0.0560
DEBUG - 2017-12-30 21:40:38 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:40:38 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:40:38 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:40:38 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:40:38 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:40:38 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:40:38 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:40:38 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/partial_invoice_table.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/index.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/filter/views/jquery_filter.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 21:40:38 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 21:40:38 --> Total execution time: 0.0406
DEBUG - 2017-12-30 21:40:43 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 21:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 21:40:43 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 21:40:43 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 21:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 21:40:43 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
DEBUG - 2017-12-30 21:40:43 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 21:40:44 --> Total execution time: 0.5524
DEBUG - 2017-12-30 22:50:36 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:50:36 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:50:36 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:50:36 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:50:36 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:50:36 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:50:36 --> Total execution time: 0.0683
DEBUG - 2017-12-30 22:51:50 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:51:50 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:51:50 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:51:50 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:51:50 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:51:50 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:51:50 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:51:50 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:51:50 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:51:50 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:51:50 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:51:50 --> Total execution time: 0.0564
DEBUG - 2017-12-30 22:51:54 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:51:54 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:51:54 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:51:54 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:51:54 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:51:54 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:51:54 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:51:55 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:51:55 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:51:55 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:51:55 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:51:55 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:51:55 --> Total execution time: 0.0570
DEBUG - 2017-12-30 22:52:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:52:00 --> Dashboard MX_Controller Initialized
DEBUG - 2017-12-30 22:52:00 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:52:00 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_amounts.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quote_amounts.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/quotes/models/Mdl_quotes.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/projects/models/Mdl_projects.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tasks/models/Mdl_tasks.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/dashboard/views/index.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:52:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:52:00 --> Total execution time: 0.0548
DEBUG - 2017-12-30 22:52:05 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:52:05 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:52:05 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:52:05 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:52:05 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:52:05 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:52:05 --> Total execution time: 0.0621
DEBUG - 2017-12-30 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:52:09 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:52:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:52:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:52:09 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:52:09 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:52:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:52:10 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:52:10 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:52:10 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:52:10 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:52:10 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:52:10 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:52:10 --> Total execution time: 0.0698
DEBUG - 2017-12-30 22:52:27 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:52:27 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:52:27 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:52:27 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:52:27 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:52:27 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:52:27 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:52:28 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:52:28 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:52:28 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:52:28 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:52:28 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:52:28 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:52:28 --> Total execution time: 0.0586
DEBUG - 2017-12-30 22:56:09 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:56:09 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:56:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:56:09 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:56:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:56:09 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:56:09 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:56:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:56:09 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:56:09 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/sidebar.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:56:09 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:56:09 --> Total execution time: 0.0780
DEBUG - 2017-12-30 22:58:51 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:58:51 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:58:51 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:58:51 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:58:51 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:58:51 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:58:51 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 22:58:51 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:58:51 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:58:51 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/sidebar.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:58:51 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:58:51 --> Total execution time: 0.0574
DEBUG - 2017-12-30 22:59:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:59:02 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 22:59:02 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:59:02 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 22:59:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:59:02 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 22:59:02 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:59:02 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/partial_invoice_table.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/views/index.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/filter/views/jquery_filter.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/sidebar.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 22:59:02 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 22:59:02 --> Total execution time: 0.0442
DEBUG - 2017-12-30 22:59:07 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 22:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 22:59:07 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 22:59:07 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 22:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 22:59:07 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
DEBUG - 2017-12-30 22:59:07 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 22:59:07 --> Total execution time: 0.5740
DEBUG - 2017-12-30 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 23:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 23:01:59 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 23:01:59 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 23:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 23:01:59 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 23:01:59 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 23:01:59 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 23:01:59 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 23:02:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 23:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 23:02:00 --> Settings MX_Controller Initialized
DEBUG - 2017-12-30 23:02:00 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 23:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 23:02:00 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 23:02:00 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/payment_gateways.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoice_groups/models/Mdl_invoice_groups.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/tax_rates/models/Mdl_tax_rates.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/email_templates/models/Mdl_email_templates.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_versions.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_templates.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/header_buttons.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/alerts.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_general.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_invoices.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_quotes.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_taxes.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_email.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_online_payment.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_projects_tasks.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/partial_settings_updates.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/views/index.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/head.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/navbar.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/sidebar.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/includes/fullpage-loader.php
DEBUG - 2017-12-30 23:02:00 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/layout/views/layout.php
DEBUG - 2017-12-30 23:02:00 --> Total execution time: 0.0594
DEBUG - 2017-12-30 23:16:25 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 23:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 23:16:25 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 23:16:25 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 23:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 23:16:25 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
ERROR - 2017-12-30 23:16:25 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 304
ERROR - 2017-12-30 23:16:25 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
ERROR - 2017-12-30 23:16:25 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
ERROR - 2017-12-30 23:16:25 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 307
ERROR - 2017-12-30 23:16:25 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 308
ERROR - 2017-12-30 23:16:25 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
DEBUG - 2017-12-30 23:16:25 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 23:16:26 --> Total execution time: 1.4480
DEBUG - 2017-12-30 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 23:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 23:17:35 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 23:17:35 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 23:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 23:17:35 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
ERROR - 2017-12-30 23:17:35 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 307
ERROR - 2017-12-30 23:17:35 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 308
ERROR - 2017-12-30 23:17:35 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
DEBUG - 2017-12-30 23:17:35 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 23:17:36 --> Total execution time: 0.9734
DEBUG - 2017-12-30 23:21:33 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 23:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 23:21:33 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 23:21:33 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 23:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 23:21:33 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
ERROR - 2017-12-30 23:21:33 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 307
ERROR - 2017-12-30 23:21:33 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 308
ERROR - 2017-12-30 23:21:33 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
DEBUG - 2017-12-30 23:21:33 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 23:21:34 --> Total execution time: 0.8711
DEBUG - 2017-12-30 23:21:42 --> UTF-8 Support Enabled
DEBUG - 2017-12-30 23:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-30 23:21:42 --> Invoices MX_Controller Initialized
DEBUG - 2017-12-30 23:21:42 --> Config file loaded: /home/jedanka/system.jedanka.com/application/config/invoice_plane.php
DEBUG - 2017-12-30 23:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/settings/models/Mdl_settings.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/controllers/../modules/layout/controllers/Layout.php
DEBUG - 2017-12-30 23:21:42 --> Layout MX_Controller Initialized
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoices.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_items.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/invoices/models/Mdl_invoice_tax_rates.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_custom_fields.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payment_methods/models/Mdl_payment_methods.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/payments/models/Mdl_payments.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_invoice_custom.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_values/models/Mdl_custom_values.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_client_custom.php
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/modules/custom_fields/models/Mdl_user_custom.php
ERROR - 2017-12-30 23:21:42 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 307
ERROR - 2017-12-30 23:21:42 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 308
ERROR - 2017-12-30 23:21:42 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
DEBUG - 2017-12-30 23:21:42 --> File loaded: /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php
DEBUG - 2017-12-30 23:21:43 --> Total execution time: 0.9053
ERROR - 2017-12-30 23:25:38 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 307
ERROR - 2017-12-30 23:25:38 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 308
ERROR - 2017-12-30 23:25:38 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
ERROR - 2017-12-30 23:25:49 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 307
ERROR - 2017-12-30 23:25:49 --> Severity: Notice --> Undefined offset: 0 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 308
ERROR - 2017-12-30 23:25:49 --> Severity: Notice --> Undefined index: 000 /home/jedanka/system.jedanka.com/application/views/invoice_templates/pdf/InvoicePlane.php 301
