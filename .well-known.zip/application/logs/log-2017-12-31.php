<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-31 07:45:09 --> 404 Page Not Found: /index
