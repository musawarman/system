<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-17 10:33:56 --> 404 Page Not Found: /index
ERROR - 2018-01-17 12:03:10 --> 404 Page Not Found: /index
