<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-01 11:35:16 --> 404 Page Not Found: /index
