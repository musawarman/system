<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-29 04:36:22 --> 404 Page Not Found: /index
ERROR - 2018-11-29 04:36:38 --> 404 Page Not Found: /index
