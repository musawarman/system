<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-27 14:17:28 --> 404 Page Not Found: /index
