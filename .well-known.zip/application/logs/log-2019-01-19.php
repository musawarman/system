<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-19 18:28:41 --> Could not find the language line "Vendors"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "Vendors"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "Add Vendor"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "Add Vendor"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "View Vendors"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "View Vendors"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "DO"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "DO"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "Create DO"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "Create DO"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "View DO"
ERROR - 2019-01-19 18:28:41 --> Could not find the language line "View DO"
