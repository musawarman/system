<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-23 10:43:20 --> 404 Page Not Found: /index
ERROR - 2019-01-23 10:43:21 --> 404 Page Not Found: /index
