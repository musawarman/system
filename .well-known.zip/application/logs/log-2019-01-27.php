<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-27 13:16:38 --> 404 Page Not Found: /index
ERROR - 2019-01-27 13:17:08 --> 404 Page Not Found: /index
